//1
describe('positiveSum', () => {
    // 1.1
    it('should return all the numbers \
    when numbers are positive', () => {
        expect(positiveSum([1])).toBe(1);
        expect(positiveSum([20, 10, 0.1])).toBe(30.1);
    });



    
// 1.2
it('shouldn add the negative numbers into the sum \
when there is a negative number in the provided array', () => {
    expect(positiveSum([-2, 1, 3])).toBe(4);
});


//1.3


it('should return 0 when the provided array is empty', () => {
    expect(positiveSum([])).toBe(0);
});




// 1.4
    it('can return zero(0) \
    when the array is all negative numbers', () => {
        expect(positiveSum([-1, -2, -3, -4])).toBe(0);
    })
});




    //2
    describe('isDivisible ', () => {
//2.1

        it(' return true \
        when a number is divisible by both of the provided divisors', () => {
            expect(isDivisible(12, 3, 4)).toBe(true);
            expect(isDivisible(12, 12, 12)).toBe(true);
            expect(isDivisible(-12, -3, -4)).toBe(true);
        });
        //2.2
        it('should return false \
        when the number is small than the provided divisors', () => {
            expect(isDivisible(1, 2, 2)).toBe(false);
            expect(isDivisible(-12, -3, 4)).toBe(false);
            expect(isDivisible(6, 12, 24)).toBe(false);
        });
  


     // 2.3
     it('should return false when the number \
     is not divisible by only one of the provided divisors', () => {
         expect(isDivisible(6, 3, 4)).toBe(false);
         expect(isDivisible(6, 0, 3)).toBe(false);
     });
    

     // 2.4

     it('should return false when the number \
    is not divisible by any of the provided divisors', () => {
        expect(isDivisible(10, 0, 0)).toBe(false);
        expect(isDivisible(9, 2, -4)).toBe(false);
    });
});


// 3
describe('solution', () => {
    // 3.1
    it('should return themselves\
    when there is only 1 character in the string', () => {
        expect(solution('5')).toBe('5');
        expect(solution(' ')).toBe(' ');
    });

    // 3.2
    it('shoud return the reversed string \
    when there are multiple characters in the string', () => {
        expect(solution('sb')).toBe('bs');
        expect(solution('123')).toBe('321');
    });

    // 3.3
    it('should return empty string \
    when there are no characters in the string', () => {
        expect(solution('')).toBe('');
    });
});

//4
describe('reverseSeq', () => {
    // 4.1
    it(' return an array of numbers if the provided number is biger than 1; \
    that begins with the provided number and has a common difference of -1; \
    the last number in the array should be between 1 (inclusive) and 0 (exclusive).', () => {
        expect(reverseSeq(3)).toEqual([3, 2, 1]);
        expect(reverseSeq(6.5)).toEqual([6.5,5.5, 4.5, 3.5, 2.5, 1.5, 0.5]);
    });

    // 4.2
    it(' return an array that contains only the provided number itself \
    if the number is between 1 (inclusive) and 0 (exclusive)', () => {
        expect(reverseSeq(1)).toEqual([1]);
        expect(reverseSeq(0.001)).toEqual([0.001]);
    });

    // 4.3
    it(' return an empty array \
    if the given number is less than or equal to 0', () => {
        expect(reverseSeq(0)).toEqual([]);
        expect(reverseSeq(-1)).toEqual([]);
    });

    // 4.4
    it(' treat the given argument as a number \
    if the argument is a string that reperesents a numbervalue', () => {
        expect(reverseSeq('5')).toEqual([5, 4, 3, 2, 1]);
        expect(reverseSeq('0')).toEqual([]);
    });

});
//4.5
    //4.6
    